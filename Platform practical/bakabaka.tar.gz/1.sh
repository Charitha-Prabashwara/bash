#!/bin/bash

function 1a(){
    ls -l
}

function 2a(){
    ls -al
}

function 3a(){
    ls -sh
}

function 4a(){
    echo "enrter tar archive name:"
    read -r input

    if [ "$input" == "" ]; then
        echo "Cannot empty filename"
        exit
    fi

    tar -cvf "$input".tar.gz --exclude=*.txt .
}

4a