#!/bin/bash

function 1a(){
    ls -l
}

function 2a(){
    ls -al
}

function 3a(){
    ls -s
}
2a